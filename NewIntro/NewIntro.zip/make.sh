#!/bin/bash
../../MADS/mp intro.pas -code:0c00
../../MADS/mads intro.a65 -x -i:../../MADS/base -o:intro.xex
